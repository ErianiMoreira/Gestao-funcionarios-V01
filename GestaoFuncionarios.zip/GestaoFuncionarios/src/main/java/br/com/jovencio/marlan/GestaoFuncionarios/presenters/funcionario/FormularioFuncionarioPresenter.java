package br.com.jovencio.marlan.GestaoFuncionarios.presenters.funcionario;

import br.com.jovencio.marlan.GestaoFuncionarios.collections.FuncionarioCollection;
import br.com.jovencio.marlan.GestaoFuncionarios.models.Funcionario;
import br.com.jovencio.marlan.GestaoFuncionarios.view.funcionario.FormularioFuncionarioView;
import java.awt.event.ActionEvent;
import java.util.Optional;
import javax.swing.WindowConstants;

/**
 *
 * @author marlan
 */
public class FormularioFuncionarioPresenter {

	private final FuncionarioCollection collection = FuncionarioCollection.getInstancia();
	private FormularioFuncionarioView view;
	private String estado = "VISUALIZACAO";
	private Integer row=0;

	public FormularioFuncionarioPresenter( String estado ) {
		this.estado = estado;
		initView();
		view.setVisible( true );
	}
        
        public FormularioFuncionarioPresenter( String estado, int row ){
		this.estado = estado;
		this.row = row;
		initView();
		view.setVisible( true );
	}

	private void salvarFuncionario() {
		var nome = view.getFldNome().getText();
		var cargo = view.getFldCargo().getText();
		var salarioBaseString = view.getFldSalarioBase().getText();
		var salarioBase = Double.valueOf( salarioBaseString );

		if( "CRIACAO".equals( estado ) ) {
			this.collection.adicionar( new Funcionario( nome, cargo, salarioBase ) );
		} else if( "EDICAO".equals( estado ) ) {
			Optional<Funcionario> funcionario = this.collection.encontrarPelaTabela( row );
			if( funcionario.isPresent() ) {
				funcionario.get().setNome( nome );
				funcionario.get().setCargo( cargo );
				funcionario.get().setSalarioBase( salarioBase );
				this.collection.notificarObservadores();
			}
		}

		view.getFldNome().setText( "" );
		view.getFldCargo().setText( "" );
		view.getFldSalarioBase().setText( "" );

		view.setVisible( false );
	}

	public boolean isVisible() {
		return view.isVisible();
	}

	public void setVisibilidade( boolean visivel ) {
		this.view.setVisible( visivel );
	}

	public void restart( String estado ) {
		restart( estado, null );
	}

	public void restart( String estado, Integer row ) {
		view.setVisible( false );
		this.estado = estado;
		this.row = row;
		init();
		view.setVisible( true );
	}

	private boolean isVisualizacao() {
		return "VISUALIZACAO".compareTo( estado ) == 0;
	}

	private void init() {
		view.getBtnSalvar().setVisible( !isVisualizacao() );
		view.getFldNome().setEditable( !isVisualizacao() );
		view.getFldCargo().setEditable( !isVisualizacao() );
		view.getFldSalarioBase().setEditable( !isVisualizacao() );

		var funcionario = collection.encontrarPelaTabela( row );
		if( funcionario.isPresent() ) {
			view.getFldNome().setText( funcionario.get().getNome() );
			view.getFldCargo().setText( funcionario.get().getCargo() );
			view.getFldSalarioBase().setText( funcionario.get().getSalarioBase().toString() );
		}
	}

	private void initView() {
		view = new FormularioFuncionarioView();
		view.setDefaultCloseOperation( WindowConstants.HIDE_ON_CLOSE );
		view.setVisible( false );
		view.getBtnSalvar().addActionListener( ( ActionEvent ae ) -> salvarFuncionario() );
		init();
	}
}
