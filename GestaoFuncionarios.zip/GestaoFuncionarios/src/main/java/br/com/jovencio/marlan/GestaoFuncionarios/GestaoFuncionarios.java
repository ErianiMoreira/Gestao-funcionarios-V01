package br.com.jovencio.marlan.GestaoFuncionarios;

import br.com.jovencio.marlan.GestaoFuncionarios.collections.FuncionarioCollection;
import br.com.jovencio.marlan.GestaoFuncionarios.presenters.PrincipalPresenter;

/**
 *
 * @author marlan
 */
public class GestaoFuncionarios {

	public static void main( String[] args ) {
		FuncionarioCollection.getInstancia();
		new PrincipalPresenter();
	}

}
