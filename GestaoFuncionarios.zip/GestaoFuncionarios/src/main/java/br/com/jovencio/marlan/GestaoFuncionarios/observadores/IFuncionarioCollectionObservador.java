
package br.com.jovencio.marlan.GestaoFuncionarios.observadores;

/**
 *
 * @author marlan
 */
public interface IFuncionarioCollectionObservador {

	public void atualizar( IFuncionarioCollectionObservavel observavel );
}
