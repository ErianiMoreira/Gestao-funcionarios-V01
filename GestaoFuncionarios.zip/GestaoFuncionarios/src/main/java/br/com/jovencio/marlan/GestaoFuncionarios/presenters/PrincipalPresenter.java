package br.com.jovencio.marlan.GestaoFuncionarios.presenters;

import br.com.jovencio.marlan.GestaoFuncionarios.collections.FuncionarioCollection;
import br.com.jovencio.marlan.GestaoFuncionarios.presenters.funcionario.FormularioFuncionarioPresenter;
import br.com.jovencio.marlan.GestaoFuncionarios.presenters.funcionario.ListagemFuncionariosPresenter;
import br.com.jovencio.marlan.GestaoFuncionarios.view.PricipalView;
import java.awt.event.ActionEvent;

/**
 *
 * @author marlan
 */
public class PrincipalPresenter {

	private final PricipalView view;

	private ListagemFuncionariosPresenter listagemFuncionarioPresenter;

	private FormularioFuncionarioPresenter formularioFuncionarioPresenter;

	private final FuncionarioCollection funcionarioCollection = FuncionarioCollection.getInstancia();

	public PrincipalPresenter() {
		view = new PricipalView();
		view.setVisible( false );
		view.getBtnConsultaFuncionario().addActionListener( ( ActionEvent ae ) -> consultaFuncionario() );
		view.getBtnIncluirFuncionario().addActionListener( ( ActionEvent ae ) -> incluirFuncionario() );
		view.setVisible( true );
	}

	private void consultaFuncionario() {
		if( listagemFuncionarioPresenter == null ) {
			listagemFuncionarioPresenter = new ListagemFuncionariosPresenter();
			this.funcionarioCollection.adicionarObservador( listagemFuncionarioPresenter );
		}
		if( !listagemFuncionarioPresenter.isVisible() ) {
			listagemFuncionarioPresenter.setVisibilidade( true );
		}
	}

	private void incluirFuncionario() {
		if( formularioFuncionarioPresenter == null ) {
			formularioFuncionarioPresenter = new FormularioFuncionarioPresenter( "CRIACAO" );
		}
		if( !formularioFuncionarioPresenter.isVisible() ) {
			formularioFuncionarioPresenter.setVisibilidade( true );
		}
	}

}
