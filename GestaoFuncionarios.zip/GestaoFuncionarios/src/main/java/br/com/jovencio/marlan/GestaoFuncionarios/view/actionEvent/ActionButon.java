
package br.com.jovencio.marlan.GestaoFuncionarios.view.actionEvent;

import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.JButton;
import javax.swing.border.EmptyBorder;

/**
 *
 * @author marlan
 */
public class ActionButon extends JButton {

	private boolean mousePress;

	public ActionButon() {
		setContentAreaFilled( false );
		setBorder( new EmptyBorder( 3, 3, 3, 3 ) );
		addMouseListener( new MouseAdapter() {

			@Override
			public void mousePressed( MouseEvent e ) {
				mousePress = true;
			}

			@Override
			public void mouseReleased( MouseEvent e ) {
				mousePress = false;
			}

		} );
	}

}
