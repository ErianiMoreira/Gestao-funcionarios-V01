package br.com.jovencio.marlan.GestaoFuncionarios.collections;

import br.com.jovencio.marlan.GestaoFuncionarios.models.Funcionario;
import br.com.jovencio.marlan.GestaoFuncionarios.observadores.IFuncionarioCollectionObservador;
import br.com.jovencio.marlan.GestaoFuncionarios.observadores.IFuncionarioCollectionObservavel;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Stream;

/**
 *
 * @author marlan
 */
public class FuncionarioCollection implements IFuncionarioCollectionObservavel {

	private static FuncionarioCollection instancia = null;
	private final Set<Funcionario> funcionarios;
	private List<IFuncionarioCollectionObservador> observadores;

	private FuncionarioCollection() {
		this.funcionarios = new HashSet<>();
	}

	public static FuncionarioCollection getInstancia() {
		if( instancia == null ) {
			instancia = new FuncionarioCollection();
		}
		return instancia;
	}

	public Set<Funcionario> getFuncionarios() {
		return funcionarios;
	}

	public void adicionar( Funcionario funcionario ) {
		if( !this.funcionarios.stream().anyMatch( f -> funcionario.equals( f ) ) ) {
			this.funcionarios.add( funcionario );
			this.notificarObservadores();
		}
	}

	public void remover( Funcionario funcionario ) {
		this.funcionarios.removeIf( f -> f.equals( funcionario ) );
		this.notificarObservadores();
	}

	public int size() {
		return this.funcionarios.size();
	}

	@Override
	public void adicionarObservador( IFuncionarioCollectionObservador observador ) {
		if( observadores == null ) {
			observadores = new ArrayList<>();
		}
		observadores.add( observador );
	}

	@Override
	public void removerObservador( IFuncionarioCollectionObservador observador ) {
		if( observadores == null ) {
			return;
		}

		if( observadores.contains( observador ) ) {
			observadores.remove( observador );
		}
	}

	@Override
	public void notificarObservadores() {
		if( observadores == null || observadores.isEmpty() ) {
			return;
		}

		observadores.forEach( observador -> observador.atualizar( this ) );
	}

	public Optional<Funcionario> encontrarPelaTabela( int row ) {
		if( size() <= row ) {
			return Optional.empty();
		}
		return Optional.of( getListagemTabela().toList().get( row ) );
	}

	public Stream<Funcionario> getListagemTabela() {
		return funcionarios.stream().sorted( Funcionario::compare );
	}

}
