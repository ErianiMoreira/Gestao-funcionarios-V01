package br.com.jovencio.marlan.GestaoFuncionarios.models;

import br.com.jovencio.marlan.GestaoFuncionarios.validators.StringValidator;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

/**
 *
 * @author marlan
 */
public class Funcionario {

	private String nome;

	private String cargo;

	private Double salarioBase = 0D;

	public Funcionario( String nome, String cargo, Double salarioBase ) {
		List<String> erros = new ArrayList<>();
		if( StringValidator.isNullOrEmptyOrOnlySpaces( cargo ) ) {
			erros.add( "o atributo 'cargo' não pode ser nulo, vazio ou apenas espaços" );
		}

		if( StringValidator.isNullOrEmptyOrOnlySpaces( nome ) ) {
			erros.add( "o atributo 'nome' não pode ser nulo, vazio ou apenas espaços" );
		}

		if( salarioBase == null || salarioBase.compareTo( 0D ) < 0 ) {
			erros.add( "o atributo 'salarioBase' não pode ser nulo ou negativo" );
		}

		if( !erros.isEmpty() ) {
			throw new IllegalArgumentException( String.join( "; ", erros ) );
		}

		this.nome = nome;
		this.cargo = cargo;
		this.salarioBase = salarioBase;
	}

	public String getNome() {
		return nome;
	}

	public void setNome( String nome ) {
		if( StringValidator.isNullOrEmptyOrOnlySpaces( nome ) ) {
			throw new IllegalArgumentException( "o atributo 'nome' não pode ser nulo, vazio ou apenas espaços." );
		}
		this.nome = nome;
	}

	public String getCargo() {
		return cargo;
	}

	public void setCargo( String cargo ) {
		if( StringValidator.isNullOrEmptyOrOnlySpaces( cargo ) ) {
			throw new IllegalArgumentException( "o atributo 'cargo' não pode ser nulo, vazio ou apenas espaços." );
		}
		this.cargo = cargo;
	}

	public Double getSalarioBase() {
		return salarioBase;
	}

	public void setSalarioBase( Double salarioBase ) {
		if( salarioBase == null || salarioBase.compareTo( 0D ) < 0 ) {
			throw new IllegalArgumentException( "o atributo 'salarioBase' não pode ser nulo ou negativo." );
		}
		this.salarioBase = salarioBase;
	}

	public static int compare( Funcionario x, Funcionario y ) {
		if( x == null || y == null ) {
			return -1;
		}
		var compareNomes = x.getNome().compareTo( y.getNome() );
		if( compareNomes == 0 ) {
			var compareCargos = x.getCargo().compareTo( y.getCargo() );
			if( compareCargos == 0 ) {
				return x.getSalarioBase().compareTo( y.getSalarioBase() );
			}
			return compareCargos;

		}
		return compareNomes;
	}

	@Override
	public boolean equals( Object obj ) {
		if( super.equals( obj ) ) {
			return true;
		} else if( !( obj instanceof Funcionario ) ) {
			return false;
		}
		var outro = ( Funcionario ) obj;
		return !Objects.isNull( outro )//
				&& nome != null && outro.nome != null && nome.compareToIgnoreCase( outro.nome ) == 0 //
				&& cargo != null && outro.cargo != null && cargo.compareToIgnoreCase( outro.cargo ) == 0 //
				&& Double.compare( salarioBase, outro.salarioBase ) == 0;
	}

	@Override
	public int hashCode() {
		int hash = 5;
		hash = Objects.hashCode( this.nome ) + 83 * hash;
		hash = Objects.hashCode( this.cargo ) + 83 * hash;
		hash = Objects.hashCode( this.salarioBase ) + 83 * hash;
		return hash;
	}

}
