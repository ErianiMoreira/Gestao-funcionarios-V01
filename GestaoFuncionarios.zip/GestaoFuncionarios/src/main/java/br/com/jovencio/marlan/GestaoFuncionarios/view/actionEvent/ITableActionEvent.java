
package br.com.jovencio.marlan.GestaoFuncionarios.view.actionEvent;

/**
 *
 * @author marlan
 */
public interface ITableActionEvent {

	public void visualizacao( int row );

	public void edicao( int row );

	public void exclusao( int row );

}
