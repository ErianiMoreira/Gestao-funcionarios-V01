
package br.com.jovencio.marlan.GestaoFuncionarios.view.actionEvent;

import java.awt.Component;
import javax.swing.DefaultCellEditor;
import javax.swing.JCheckBox;
import javax.swing.JTable;

/**
 *
 * @author marlan
 */
public class TableActionCellEditor extends DefaultCellEditor {

	private final ITableActionEvent event;

	public TableActionCellEditor( ITableActionEvent event ) {
		super( new JCheckBox() );
		this.event = event;
	}

	@Override
	public Component getTableCellEditorComponent( JTable table, Object value, boolean isSelected, int row, int column ) {
		var action = new PanelAction();
		action.initEvent( event, row );
		action.setBackground( table.getSelectionBackground() );
		return action;
	}

}
