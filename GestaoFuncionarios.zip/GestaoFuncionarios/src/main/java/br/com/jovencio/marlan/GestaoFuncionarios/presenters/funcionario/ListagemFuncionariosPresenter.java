package br.com.jovencio.marlan.GestaoFuncionarios.presenters.funcionario;

import br.com.jovencio.marlan.GestaoFuncionarios.collections.FuncionarioCollection;
import br.com.jovencio.marlan.GestaoFuncionarios.observadores.IFuncionarioCollectionObservador;
import br.com.jovencio.marlan.GestaoFuncionarios.observadores.IFuncionarioCollectionObservavel;
import br.com.jovencio.marlan.GestaoFuncionarios.view.actionEvent.ITableActionEvent;
import br.com.jovencio.marlan.GestaoFuncionarios.view.actionEvent.TableActionCellEditor;
import br.com.jovencio.marlan.GestaoFuncionarios.view.actionEvent.TableActionCellRender;
import br.com.jovencio.marlan.GestaoFuncionarios.view.funcionario.ListagemFuncionariosView;
import javax.swing.WindowConstants;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author marlan
 */
public class ListagemFuncionariosPresenter implements IFuncionarioCollectionObservador {

	private final FuncionarioCollection funcionarioCollection = FuncionarioCollection.getInstancia();
	private FormularioFuncionarioPresenter formularioFuncionarioPresenter;
	private final ListagemFuncionariosView view;

	public ListagemFuncionariosPresenter() {
		view = new ListagemFuncionariosView();
		view.setVisible( false );
		view.setDefaultCloseOperation( WindowConstants.HIDE_ON_CLOSE );
		gerarLinhasTabela();
		view.setVisible( true );

	}

	private void gerarLinhasTabela() {
		DefaultTableModel model = ( DefaultTableModel ) view.getTblFuncionarios().getModel();
		model.setNumRows( 0 );

		ITableActionEvent event = new ITableActionEvent() {

			@Override
			public void visualizacao( int row ) {
				visualizar( row );
			}

			@Override
			public void edicao( int row ) {
				editar( row );
			}

			@Override
			public void exclusao( int row ) {
				excluir( row );
			}
		};
		view.getTblFuncionarios().getColumnModel().getColumn( 3 ).setCellRenderer( new TableActionCellRender() );
		view.getTblFuncionarios().getColumnModel().getColumn( 3 ).setCellEditor( new TableActionCellEditor( event ) );

		funcionarioCollection.getListagemTabela().forEach( funcionario -> model.addRow( new Object[]{ funcionario.getNome(), funcionario.getCargo(), funcionario.getSalarioBase() } ) );
	}

	public boolean isVisible() {
		return this.view.isVisible();
	}

	public void setVisibilidade( boolean visivel ) {
		this.view.setVisible( visivel );
	}

	@Override
	public void atualizar( IFuncionarioCollectionObservavel observavel ) {
		this.gerarLinhasTabela();
	}

	private void visualizar( int row ) {
		if( !funcionarioCollection.encontrarPelaTabela( row ).isPresent() ) {
			return;
		}

		if( formularioFuncionarioPresenter == null ) {
			formularioFuncionarioPresenter = new FormularioFuncionarioPresenter( "VISUALIZACAO", row );
		} else {
			formularioFuncionarioPresenter.restart( "VISUALIZACAO", row );
		}

	}

	private void editar( int row ) {
		var funcionario = funcionarioCollection.encontrarPelaTabela( row );
		if( !funcionario.isPresent() ) {
			return;
		}
		if( formularioFuncionarioPresenter == null ) {
			formularioFuncionarioPresenter = new FormularioFuncionarioPresenter( "EDICAO", row );
		} else {
			formularioFuncionarioPresenter.restart( "EDICAO", row );
		}
	}

	private void excluir( int row ) {
		if( view.getTblFuncionarios().isEditing() ) {
			view.getTblFuncionarios().getCellEditor().stopCellEditing();
		}
		var funcionario = funcionarioCollection.encontrarPelaTabela( row );
		if( funcionario.isPresent() ) {
			funcionarioCollection.remover( funcionario.get() );
		}
	}
}
