package br.com.jovencio.marlan.GestaoFuncionarios.validators;

/**
 *
 * @author marlan
 */
public class StringValidator {

	public static boolean isNullOrEmptyOrOnlySpaces( String value ) {
		return value == null || value.isEmpty() || value.isBlank() || value.trim().isBlank() || value.trim().isEmpty() || value.replace( " ", "" ).length() <= 0;
	}

}
