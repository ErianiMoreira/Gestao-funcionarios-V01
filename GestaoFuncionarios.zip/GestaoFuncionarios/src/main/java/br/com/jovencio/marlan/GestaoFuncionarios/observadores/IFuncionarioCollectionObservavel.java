
package br.com.jovencio.marlan.GestaoFuncionarios.observadores;

/**
 *
 * @author marlan
 */
public interface IFuncionarioCollectionObservavel {

	public void adicionarObservador( IFuncionarioCollectionObservador observador );

	public void removerObservador( IFuncionarioCollectionObservador observador );

	public void notificarObservadores();

}
